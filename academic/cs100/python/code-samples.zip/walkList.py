# Some sample lists 
data = [22, 45, 5, -1, 33, 65, 35, 29, -40]
#data = [-40, 25, -60, 71, 68, 100, 25]

for i in range(0, len(data), 1):                  
   print(data[i])
