# Input: Collect two numbers from the user
num1 = eval(input("Enter a number: "))
num2 = eval(input("Enter another number: "))

# Process: Add the two inputs
sum = num1 + num2

# Output: Report the sum 
print("The sum of your numbers: ", sum)